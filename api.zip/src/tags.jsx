const tags = [
  {
    title: "Лучшие сериалы",
    url: "discover/tv?sort_by=popularity.desc&page=1"
  },
  {
    title: "Актуальные",
    url: "discover/movie?sort_by=popularity.desc&page=1"
  },
  {
    title: "Фильмы ужасов",
    url: "genre/27/movies?sort_by=popularity.desc&page=1"
  },
  {
    title: "Научно-фантастические",
    url: "genre/878/movies?sort_by=popularity.desc&page=1"
  },
  {
    title: "Комедии",
    url: "genre/35/movies?sort_by=popularity.desc&page=1"
  }
];

export default tags;
