import React from "react";
import "./styles.css";
import narcosLogo from "./images/narcos-logo.png";
import tags from "./tags";
import Row from "./Row";
import Logo from "./images/Logo";
import avatar from "./images/icon.webp";
import UserInfo from "./UserInfo";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchItems: null,
      isSearch: false,
      error: undefined
    };
    this.sub = this.sub.bind(this);
  }
  sub(e) {
    e.preventDefault();
    let value = e.target.value.value;
    let url = `https://api.themoviedb.org/3/search/movie?api_key=87dfa1c669eea853da609d4968d294be&language=en-US&query=${value}&page=1`;
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({
          isSearch: true,
          searchItems: data
        });
      })
      .catch(error => this.setState({ error, isSearch: false }));
  }
  render() {
    const { isSearch, searchItems, error } = this.state;
    return (
      <div className="App">
        <nav>
          <Logo />
          <ul className="links">
            <li>
              <a href="/">Поиск</a>
            </li>
            <li>
              <a href="/">Мой список</a>
            </li>
            <li>
              <a href="/">Популярное</a>
            </li>
            <li>
              <a href="/">Недавнее</a>
            </li>
          </ul>
          <form onSubmit={this.sub} className="searchForm">
            <input
              id="value"
              name="value"
              type="text"
              placeholder="Поиск по названию"
            />
          </form>
          <UserInfo name="Андрей Иванов" avatar={avatar} />
        </nav>
        <div className="narcos">
          <img src={narcosLogo} alt="NARCOS" />
          <h1>Второй сезон теперь доступен</h1>
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quidem
            quos debitis voluptates eaque harum pariatur laboriosam iste
            dolorem. Quisquam, veniam!
          </p>
          <button id="redButton">Смотреть сейчас</button>
          <button>+ Мой список</button>
        </div>
        {isSearch ? (
          <div className="line">
            <h1>Результаты поиска</h1>
            <div className="row">
              {error ? <p>{error.message}</p> : null}
              {searchItems.results.map(item => {
                console.log(JSON.stringify(item));
                return (
                  <img
                    key={item.original_name}
                    src={
                      "https://image.tmdb.org/t/p/w185_and_h278_bestv2/" +
                      item.poster_path
                    }
                    alt={item.title}
                  />
                );
              })}
            </div>
          </div>
        ) : null}
        {tags.map(tag => {
          return <Row key={tag.title} title={tag.title} url={tag.url} />;
        })}
      </div>
    );
  }
}
