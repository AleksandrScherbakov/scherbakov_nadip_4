import React from "react";

const UserInfo = props => {
  return (
    <div className="userInfo">
      <a href="/">{props.name}</a>
    </div>
  );
};

export default UserInfo;
