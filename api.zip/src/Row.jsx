import React from "react";

export default class Row extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      items: {},
      error: null
    };
  }
  fetchItems(requestUrl) {
    fetch(requestUrl)
      .then(response => response.json())
      .then(data => {
        this.setState({
          items: data,
          isLoading: false
        });
      })
      .catch(error => this.setState({ error, isLoading: false }));
  }
  componentDidMount() {
    const requestUrl =
      "https://api.themoviedb.org/3/" +
      this.props.url +
      "&api_key=87dfa1c669eea853da609d4968d294be";
    this.fetchItems(requestUrl);
  }
  render() {
    const { isLoading, items, error } = this.state;
    return (
      <div className="line">
        <h1>{this.props.title}</h1>
        <div className="row">
          {error ? <p>{error.message}</p> : null}
          {!isLoading ? (
            items.results.map(item => {
              return (
                <img
                  key={item.original_name}
                  src={
                    "https://image.tmdb.org/t/p/w185_and_h278_bestv2/" +
                    item.poster_path
                  }
                  alt={item.title}
                />
              );
            })
          ) : (
            <h2>Загрузка...</h2>
          )}
        </div>
      </div>
    );
  }
}
