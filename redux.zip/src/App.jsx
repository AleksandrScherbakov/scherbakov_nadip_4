import React, { Component } from "react";
import { Route, Switch, withRouter } from "react-router-dom";
import "./styles.css";
import Whoops404 from "./components/Whoops404";
import Home from "./components/Home";
import ShowBook from "./components/ShowBook";

class App extends Component {
  render() {
    const { history } = this.props;
    return (
      <div className="App">
        <Switch>
          <Route history={history} exact path="/" component={Home} />
          <Route history={history} path="/books" component={ShowBook} />
          <Route component={Whoops404} />
        </Switch>
      </div>
    );
  }
}
export default withRouter(App);
