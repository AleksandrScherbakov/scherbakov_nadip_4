import React from "react";
import { setBook } from "../actions/bookActions";
import { connect } from "react-redux";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: 1,
      src: "",
      title: "",
      author: ""
    };
  }

  handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      this.setState({
        file: file,
        img: reader.result
      });
    };
    reader.readAsDataURL(file);
  }

  addBook = e => {
    e.preventDefault();
    let author = this.refs.author.value.trim();
    let title = this.refs.title.value.trim();
    this.props.handleSubmit({
      id: this.state.id,
      author: author,
      title: title,
      src: this.state.img
    });
    this.refs.author.value = "";
    this.refs.title.value = "";
    this.refs.image.value = "";
    this.setState({ id: this.state.id + 1 });
  };

  render() {
    return (
      <form id="add" onSubmit={this.addBook}>
        <div className="form-row">
          <div className="form-group col-md-6">
            <label htmlFor="author">Автор</label>
            <input
              type="text"
              className="form-control"
              id="author"
              ref="author"
              placeholder="Автор"
              required
              onChange={e => this.setState({ author: e.target.value })}
            />
          </div>
          <br />
          <div className="form-group col-md-6">
            <label htmlFor="image">Изображение</label>
            <input
              type="file"
              className="form-control"
              id="image"
              ref="image"
              onChange={e => this.handleImageChange(e)}
            />
          </div>
          <br />
          <div className="form-group col-md-6">
            <label htmlFor="title">Название</label>
            <input
              type="text"
              className="form-control"
              id="title"
              ref="title"
              placeholder="Название"
              required
              onChange={e => this.setState({ title: e.target.value })}
            />
          </div>
          <br />
          <button type="submit" className="btn btn-primary">
            Добавить книгу
          </button>
        </div>
      </form>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    handleSubmit: book => dispatch(setBook(book))
  };
};
export default connect(
  null,
  mapDispatchToProps
)(Form);
