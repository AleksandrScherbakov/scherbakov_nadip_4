import React from "react";
const PageTemplate = ({ children }) => {
  return (
    <div className="page col-lg-12 col-md-12 col-sm-12 container">
      <h1 className="title">Список книг</h1>
      <hr />
      {children}
    </div>
  );
};
export default PageTemplate;
