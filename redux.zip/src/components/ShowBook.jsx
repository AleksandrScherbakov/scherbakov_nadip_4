import React from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { unpickBook } from "../actions/bookActions";

class ShowBook extends React.Component {
  render() {
    let { author, title, id } = this.props.currentBook[0];
    console.log(this.props.currentBook);
    return (
      <div className="container col-sm-12">
        <h1>ID {id}</h1>
        <hr />
        <br />
        <div className="bookInfo">
          <p>Автор</p>
          <h3>{author}</h3>
        </div>
        <div className="bookInfo">
          <p>Название</p>
          <h3>{title}</h3>
        </div>
        <br />
        <hr />
        <Link
          to="/"
          onClick={() => {
            this.props.handleUnpick(id);
          }}
        >
          Назад к списку
        </Link>
      </div>
    );
  }
}
const mapStateToProps = store => {
  console.log("store: ", store);
  return {
    currentBook: store
  };
};

const mapDispatchToProps = dispatch => {
  return {
    handleUnpick: id => dispatch(unpickBook(id))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShowBook);
