import React from "react";
import { removeBook, pickBook } from "../actions/bookActions";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
class Book extends React.Component {
  render() {
    let { src, author, title, id } = this.props;
    return (
      <div className="book col-lg-6 col-md-6 col-sm-6">
        <img src={src} alt={title} />
        <br />
        <div className="info">
          <h3>{author}</h3>
          <Link to="/books" onClick={() => this.props.handlePick(id)}>
            {title}
          </Link>
          <br />
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => this.props.handleRemove(id)}
          >
            Удалить
          </button>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    handleRemove: id => dispatch(removeBook(id)),
    handlePick: id => dispatch(pickBook(id))
  };
};

export default connect(
  null,
  mapDispatchToProps
)(Book);
