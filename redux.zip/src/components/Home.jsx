import React from "react";
import Template from "./Template";
import { connect } from "react-redux";
import Book from "./Book";
import Form from "./Form";

class Home extends React.Component {
  render() {
    return (
      <Template>
        {this.props.books
          ? this.props.books.map(book => {
              return (
                <>
                  <Book key={book.id} {...book} />
                  <br />
                </>
              );
            })
          : ""}
        <br />
        <p>Добавить новую книгу:</p>
        <Form />
      </Template>
    );
  }
}

const mapStateToProps = store => {
  return {
    books: store
  };
};

export default connect(
  mapStateToProps,
  null
)(Home);
