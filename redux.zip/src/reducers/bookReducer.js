import {
  SET_BOOK,
  REMOVE_BOOK,
  PICK_BOOK,
  UNPICK_BOOK
} from "../actions/bookActions";
export const initialState = [];
export function bookReducer(state = initialState, action) {
  switch (action.type) {
    case SET_BOOK: {
      return state.concat([action.payload]);
    }
    case REMOVE_BOOK: {
      return state.filter(b => b.id !== action.payload);
    }
    case PICK_BOOK: {
      state = state.filter(b => b.id === action.payload);
      return state;
    }
    case UNPICK_BOOK: {
      state = "";
      return state;
    }
    default:
      return state;
  }
}
