export const SET_BOOK = "SET_BOOK";
export const REMOVE_BOOK = "REMOVE_BOOK";
export const PICK_BOOK = "PICK_BOOK";
export const UNPICK_BOOK = "UNPICK_BOOK";

export function setBook(book) {
  return {
    type: SET_BOOK,
    payload: book
  };
}
export function removeBook(id) {
  return {
    type: REMOVE_BOOK,
    payload: id
  };
}
export function pickBook(id) {
  return {
    type: PICK_BOOK,
    payload: id
  };
}

export function unpickBook(id) {
  return {
    type: PICK_BOOK,
    payload: id
  };
}
