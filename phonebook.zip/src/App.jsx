import React from "react";
import Menu from "./components/Menu";
import Table from "./components/Table";
import Edit from "./components/Edit";
import Add from "./components/Add";
import User from "./components/User";
import ApolloClient from "apollo-boost";
import { ApolloProvider } from "@apollo/react-hooks";
import "./styles.css";

import { useRoutes } from "hookrouter";

const routes = {
  "/": () => <Table />,
  "/add": () => <Add />,
  "/user/:id": ({ id }) => <User id={id} />,
  "/edit/:id": ({ id }) => <Edit id={id} />
};

const client = new ApolloClient({
  uri: "https://40wzh.sse.codesandbox.io/"
});

export default function App() {
  const routeResult = useRoutes(routes);

  return (
    <ApolloProvider client={client}>
      <div className="App">
        <Menu />
        {routeResult}
      </div>
    </ApolloProvider>
  );
}
