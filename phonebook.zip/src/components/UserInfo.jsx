import React from "react";
import { A } from "hookrouter";
export default function UserInfo(props) {
  const { name, tel, id } = props;
  return (
    <>
      <td>{name}</td>
      <td>{tel}</td>
      <td>
        <A href={`/user/${id}`}>
          <button type="button" className="btn btn-primary">
            Показать адрес
          </button>
        </A>
      </td>
      <td>
        <A href={`/edit/${id}`}>
          <button type="button" className="btn btn-success">
            Редактировать
          </button>
        </A>
      </td>
    </>
  );
}
