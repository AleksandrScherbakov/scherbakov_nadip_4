import React from "react";
import UserInfo from "./UserInfo";
import { useQuery } from "@apollo/react-hooks";
import { gql } from "apollo-boost";

const GET_USERS = gql`
  {
    users {
      id
      name
      tel
      city
      street
    }
  }
`;

export default function Table() {
  const { loading, error, data } = useQuery(GET_USERS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :( {JSON.stringify(error)}</p>;

  const users = data.users;
  return (
    <table className="table table-dark users-table">
      <thead>
        <tr>
          <th scope="col">№</th>
          <th scope="col">Имя</th>
          <th scope="col">Номер телефона</th>
          <th scope="col">Адрес</th>
          <th scope="col">Действие</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user, index) => (
          <tr key={user.id}>
            <th scope="row">{index + 1}</th>
            <UserInfo {...user} />
          </tr>
        ))}
      </tbody>
    </table>
  );
}
