import React, { useEffect } from "react";
import { gql } from "apollo-boost";
import { useMutation, useQuery } from "@apollo/react-hooks";
import { navigate } from "hookrouter";

const UPDATE_USER = gql`
  mutation UpdateUser($id: String!, $name: String!, $tel: String!) {
    updateUser(id: $id, name: $name, tel: $tel) {
      id
      name
      tel
    }
  }
`;
const GET_USER = gql`
  query User($id: String!) {
    user(id: $id) {
      id
      name
      tel
    }
  }
`;

export default function Edit(props) {
  const { id } = props;

  const [updateUser] = useMutation(UPDATE_USER);

  const { loading, error, data } = useQuery(GET_USER, {
    variables: { id: id },
    skip: !id
  });

  useEffect(() => {
    if (!loading && data) {
      nameInput.value = data.user.name;
      telInput.value = data.user.tel;
    }
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :( {JSON.stringify(error)}</p>;

  let telInput, nameInput;

  const update = e => {
    e.preventDefault();
    updateUser({
      variables: { id: id, name: nameInput.value, tel: telInput.value }
    });
    telInput.value = nameInput.value = "";
    navigate("/");
  };
  return (
    <div className="container editForm col-8">
      <h1>Редактировать</h1>
      <br />
      <form onSubmit={e => update(e)}>
        <div className="form-group">
          <label htmlFor="name">Имя</label>
          <input
            type="text"
            className="form-control"
            id="name"
            ref={node => {
              nameInput = node;
            }}
          />
        </div>
        <div className="form-group">
          <label htmlFor="tel">Номер телефона</label>
          <input
            type="tel"
            className="form-control"
            id="tel"
            ref={node => {
              telInput = node;
            }}
          />
        </div>
        <br />
        <button type="submit" className="btn btn-primary col-12">
          Сохранить
        </button>
      </form>
    </div>
  );
}
