import React from "react";
import { gql } from "apollo-boost";
import { useMutation } from "@apollo/react-hooks";
import { v4 as uuidv4 } from "uuid";
import { navigate } from "hookrouter";

const CREATE_USER = gql`
  mutation CreateUser(
    $id: String!
    $name: String!
    $tel: String!
    $city: String!
    $street: String!
  ) {
    createUser(id: $id, name: $name, tel: $tel, city: $city, street: $street) {
      id
      name
      tel
      city
      street
    }
  }
`;

export default function Add() {
  const [createUser] = useMutation(CREATE_USER);
  let id = uuidv4();

  let nameInput, telInput, cityInput, streetInput;

  const create = e => {
    e.preventDefault();
    createUser({
      variables: {
        id: id,
        name: nameInput.value,
        tel: telInput.value,
        city: cityInput.value,
        street: streetInput.value
      }
    });
    telInput.value = nameInput.value = cityInput.value = streetInput.value = "";
    navigate("/");
  };
  return (
    <div className="container addForm col-8">
      <h1>Добваить</h1>
      <br />
      <form onSubmit={e => create(e)}>
        <div className="form-group">
          <label htmlFor="name">Имя</label>
          <input
            type="text"
            className="form-control"
            id="name"
            ref={node => {
              nameInput = node;
            }}
          />
        </div>
        <div className="form-group">
          <label htmlFor="tel">Номер телефона</label>
          <input
            type="tel"
            className="form-control"
            id="tel"
            ref={node => {
              telInput = node;
            }}
          />
        </div>
        <div className="form-group">
          <label htmlFor="street">Название улицы</label>
          <input
            type="text"
            className="form-control"
            id="street"
            ref={node => {
              streetInput = node;
            }}
          />
        </div>
        <div className="form-group">
          <label htmlFor="city">Город</label>
          <input
            type="text"
            className="form-control"
            id="city"
            ref={node => {
              cityInput = node;
            }}
          />
        </div>
        <br />
        <button type="submit" className="btn btn-primary col-12">
          Добавить
        </button>
      </form>
    </div>
  );
}
