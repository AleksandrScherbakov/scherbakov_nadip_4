import React from "react";
import { gql } from "apollo-boost";
import { useQuery } from "@apollo/react-hooks";
import { A } from "hookrouter";

const GET_USER = gql`
  query User($id: String!) {
    user(id: $id) {
      id
      name
      tel
      street
      city
    }
  }
`;
export default function User(props) {
  const { id } = props;
  const { loading, error, data } = useQuery(GET_USER, {
    variables: { id: id },
    skip: !id
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :( {JSON.stringify(error)}</p>;

  return (
    <div className="container user col-8">
      <h3>{data.user.name}</h3>
      <br />
      <p>{data.user.street + ", " + data.user.city}</p>
      <span>{data.user.tel}</span>
      <br />
      <br />
      <A href="/">
        <button type="submit" className="btn btn-primary col-3">
          Назад
        </button>
      </A>
    </div>
  );
}
