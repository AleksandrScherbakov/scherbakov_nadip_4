import React from "react";
import { A } from "hookrouter";

export default function Menu() {
  return (
    <nav className="navbar navbar-dark bg-dark menu">
      <A className="navbar-brand" href="/">
        Телефонная книга
      </A>
      <ul className="nav justify-content-end">
        <li className="nav-item">
          <A className="nav-link active" href="/">
            Главная
          </A>
        </li>
        <li className="nav-item">
          <A className="nav-link" href="/add">
            Добавить
          </A>
        </li>
      </ul>
    </nav>
  );
}
