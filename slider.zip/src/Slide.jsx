import React from "react";

export default function Slide(props) {
  return (
    <div className="slide" style={{ backgroundImage: `url(${props.src})` }}>
      <h1 className="title">{props.title}</h1>
    </div>
  );
}
