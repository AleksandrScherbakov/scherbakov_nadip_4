import React from "react";
import "./styles.css";
import Slide from "./Slide";
import america from "./images/america.jpg";
import mountains from "./images/mountains.jpg";
import shore from "./images/shore.jpg";

const slides = [
  {
    title: "AMERICA",
    src: america
  },
  {
    title: "MOUNTAINS",
    src: mountains
  },
  {
    title: "SHORE",
    src: shore
  }
];
class App extends React.Component {
  constructor() {
    super();
    this.state = {
      index: 0
    };
    this.decr = this.decr.bind(this);
    this.incr = this.incr.bind(this);
  }
  incr() {
    if (this.state.index === 2) {
      this.setState({ index: 0 });
    } else {
      this.setState({ index: this.state.index + 1 });
    }
  }
  decr() {
    if (this.state.index === 0) {
      this.setState({ index: 2 });
    } else {
      this.setState({ index: this.state.index - 1 });
    }
  }
  render() {
    return (
      <div className="App">
        <Slide
          title={slides[this.state.index].title}
          src={slides[this.state.index].src}
        />
        <button id="left" onClick={this.decr}>
          &lt;
        </button>
        <button id="right" onClick={this.incr}>
          &gt;
        </button>
      </div>
    );
  }
}

export default App;
