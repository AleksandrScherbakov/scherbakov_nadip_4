import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import { A, navigate } from "hookrouter";
import useAuth from "../hooks/useAuth";
import getToken from "../middlewares/getToken";
const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    marginBottom: theme.spacing(2)
  },
  menuButton: {
    marginRight: theme.spacing(2)
  },
  title: {
    flexGrow: 1,
    textAlign: "left"
  }
}));

const logout = () => {
  localStorage.removeItem("token");
  navigate("/");
  document.location.reload();
};

export function Menu() {
  const classes = useStyles();
  let token = getToken();
  let { auth, user } = useAuth(token);
  return (
    <div className={classes.root}>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" className={classes.title}>
            <A href="/">Social Network</A>
          </Typography>
          {auth && user ? (
            <>
              <A href={`/user/${user.id}`}>
                <Button color="inherit">МОЙ ПРОФИЛЬ</Button>
              </A>
              <Button color="inherit" onClick={logout}>
                ВЫЙТИ
              </Button>
            </>
          ) : (
            <>
              <A href="/signup">
                <Button color="inherit">Зарегистрироваться</Button>
              </A>
              <A href="/signin">
                <Button color="inherit">Войти</Button>
              </A>
            </>
          )}
        </Toolbar>
      </AppBar>
    </div>
  );
}
