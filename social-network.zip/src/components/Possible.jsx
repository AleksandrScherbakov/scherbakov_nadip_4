import React, { useState, useEffect } from "react";
import { Typography, Paper, Button, Avatar } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import VisibilityIcon from "@material-ui/icons/Visibility";
import { A } from "hookrouter";
import { ActionButton } from "./User";
const useStyles = makeStyles(theme => ({
  image: {
    width: "100%",
    height: "100%"
  },
  text: {
    padding: theme.spacing(1.5) + " " + theme.spacing(2)
  },
  link: {
    color: "inherit",
    "&:hover": {
      color: "inherit"
    }
  },
  line: {
    margin: "0 " + theme.spacing(1)
  },
  icon: {
    margin: theme.spacing(1),
    cursor: "pointer"
  },
  large: {
    width: theme.spacing(4),
    height: theme.spacing(4)
  },
  userInfo: {
    margin: theme.spacing(1),
    background: theme.palette.primary.light
  }
}));

const UserInfo = ({ candidate, user }) => {
  const classes = useStyles();
  return (
    <div className="user-line">
      <div className="user-line-info">
        <A href={`/user/${candidate.id}`}>
          <Avatar src={candidate.avatar} />
        </A>
        <Typography variant="body1" className={classes.text}>
          <A href={`/user/${candidate.id}`} className={classes.link}>
            {candidate.login}
          </A>
        </Typography>
      </div>
      <div className="user-line-actions">
        <A href={candidate ? `/user/${candidate.id}` : ""}>
          <VisibilityIcon color="secondary" className={classes.icon} />
        </A>
        <ActionButton user={user} candidate={candidate} />
      </div>
    </div>
  );
};

const fetchSomeUsers = async (n, userId) => {
  let users = await fetch(
    `https://tj791.sse.codesandbox.io/userinfo/some/${n}`
  ).then(res => res.json());
  users = users.filter(u => u.id !== userId);
  return users;
};

export default function Possible({ user }) {
  const classes = useStyles();
  const [users, setUsers] = useState([]);
  useEffect(() => {
    if (!users.length) {
      (async () => {
        setUsers(await fetchSomeUsers(2, user.id));
      })();
    }
  }, [users, user]);
  return (
    <Paper
      className="possible"
      variant="outlined"
      elevation={3}
      children={
        <div className="container">
          <Typography variant="h5" className={classes.text} color="primary">
            Возможные подписки
          </Typography>
          <div className="container">
            {users.length > 0
              ? users.map(x => (
                  <UserInfo candidate={x} user={user} key={x.id} />
                ))
              : ""}
          </div>
        </div>
      }
    />
  );
}
