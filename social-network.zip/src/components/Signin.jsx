import React, { useState } from "react";
import { Paper, FormControl, Input, InputLabel } from "@material-ui/core";
import { Typography, Button } from "@material-ui/core";
import { navigate } from "hookrouter";

const SigninForm = ({ handleSubmit, handleChange }) => (
  <div className="signinForm">
    <Typography variant="h6" align="center" color="primary">
      Вход
    </Typography>
    <form onSubmit={e => handleSubmit(e)}>
      <FormControl margin="normal" required>
        <InputLabel htmlFor="email-input">Email</InputLabel>
        <Input
          id="email-input"
          aria-describedby="Введите Email"
          fullWidth
          type="email"
          autoFocus
          onChange={e => handleChange(e, "email")}
        />
      </FormControl>
      <br />
      <FormControl margin="normal" required>
        <InputLabel htmlFor="password-input">Пароль</InputLabel>
        <Input
          id="password-input"
          aria-describedby="Введите пароль"
          fullWidth
          type="password"
          onChange={e => handleChange(e, "password")}
        />
      </FormControl>
      <br />
      <FormControl margin="normal">
        <Button variant="contained" color="primary" type="submit">
          ВОЙТИ
        </Button>
      </FormControl>
    </form>
  </div>
);

export default function Signin() {
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

  const handleChange = (e, title) => {
    const { value } = e.currentTarget;
    if (title === "email") {
      setEmail(value);
    } else if (title === "password") {
      setPassword(value);
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await fetch("https://tj791.sse.codesandbox.io/auth/signin", {
      method: "post",
      body: JSON.stringify({ email, password }),
      headers: {
        "content-type": "application/json"
      }
    }).then(async res => {
      if (res.status === 200) {
        res = await res.json();
        localStorage.setItem("token", res.token);
        navigate("/");
      } else {
        const error = new Error(res.error);
        throw error;
      }
    });
  };
  return (
    <Paper
      className="container"
      variant="outlined"
      elevation={3}
      children={
        <SigninForm handleSubmit={handleSubmit} handleChange={handleChange} />
      }
    />
  );
}
