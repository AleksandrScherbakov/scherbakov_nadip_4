import React, { useState, useEffect, useRef } from "react";
import {
  Typography,
  Paper,
  Button,
  Avatar,
  TextField,
  Box,
  IconButton,
  CircularProgress
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import DeleteIcon from "@material-ui/icons/Delete";
import CameraAltIcon from "@material-ui/icons/CameraAlt";
import FavoriteIcon from "@material-ui/icons/Favorite";
import FavoriteBorderIcon from "@material-ui/icons/FavoriteBorder";
import ClearIcon from "@material-ui/icons/Clear";
import { v4 } from "uuid";
import { A } from "hookrouter";

const useStyles = makeStyles(theme => ({
  image: {
    width: "100%",
    height: "100%"
  },
  text: {
    padding: theme.spacing(1.5) + " " + theme.spacing(2),
    background: theme.palette.back.white
  },
  link: {
    color: "inherit",
    "&:hover": {
      color: "inherit"
    }
  },
  warning: {
    padding: theme.spacing(1.5) + " " + theme.spacing(2),
    width: "100%",
    textAlign: "center"
  },
  line: {
    margin: "0 " + theme.spacing(1)
  },
  icon: {
    margin: theme.spacing(1),
    cursor: "pointer"
  },
  feed: {
    width: "100%"
  },
  post: {
    background: theme.palette.back.light,
    marginBottom: theme.spacing(2)
  },
  createPost: {
    background: theme.palette.primary.light,
    marginBottom: theme.spacing(2)
  },
  createPostActions: {
    width: "calc(100% - " + theme.spacing(4) + " )",
    padding: theme.spacing(0.5) + " " + theme.spacing(2),
    background: theme.palette.back.white
  },
  authorInfo: {
    display: "flex",
    justifyContent: "flex-start",
    padding: theme.spacing(0.5) + " " + theme.spacing(1),
    alignItems: "center",
    width: "auto"
  },
  editField: {
    width: "100%",
    background: theme.palette.back.white
  },
  input: {
    display: "none"
  },
  createButton: {
    margin: theme.spacing(1)
  },
  userLogin: {
    marginLeft: theme.spacing(1),
    width: "calc(100% - " + theme.spacing(3) + ")",
    display: "flex",
    justifyContent: "space-between"
  },
  postImage: {
    display: "inline-block",
    maxWidth: "300px",
    maxHeight: "400px",
    margin: theme.spacing(1) + " 30%"
  },
  pending: {
    margin: `0 ${theme.spacing(1.5)}`
  },
  postDate: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignContent: "center",
    flexWrap: "wrap"
  }
}));

const fetchPosts = async userId => {
  let posts = await fetch(
    `https://tj791.sse.codesandbox.io/posts/feed/${userId}`
  ).then(res => res.json());
  posts = posts.filter(p => Object.keys(p).length !== 0);
  return posts;
};

const AuthorInfo = ({ author, date, premissions, remove }) => {
  const classes = useStyles();
  return (
    <div className={classes.authorInfo}>
      <A href={`/user/${author.id}`}>
        <Avatar src={author.avatar} />
      </A>
      <div className={classes.userLogin}>
        <div className={classes.postDate}>
          <Typography variant="body1">
            <A href={`/user/${author.id}`} className={classes.link}>
              {author.login}
            </A>
          </Typography>
          {date ? (
            <Typography variant="subtitle2" color="textSecondary">
              {date}
            </Typography>
          ) : (
            ""
          )}
        </div>
        <div>
          {premissions ? (
            <DeleteIcon className={classes.icon} onClick={remove} />
          ) : (
            ""
          )}
        </div>
      </div>
    </div>
  );
};

const CreatePost = ({ user, setPosts }) => {
  const classes = useStyles();
  const [text, setText] = useState("");
  const imageInput = useRef(null);
  const [color, setColor] = useState("secondary");
  const [pending, setPending] = useState(false);

  const createPost = async () => {
    setPending(true);
    let image = imageInput.current.files[0]?.name;
    let data = JSON.stringify({
      id: v4(),
      text,
      author: {
        id: user.id,
        avatar: user.avatar,
        login: user.login
      },
      date: new Date(),
      image
    });
    const formData = new FormData();
    formData.append("image", imageInput.current.files[0]);
    formData.append("info", data);
    await fetch(`https://tj791.sse.codesandbox.io/posts`, {
      method: "post",
      body: formData
    });
    setText("");
    setPosts(await fetchPosts(user.id));
    setPending(false);
  };

  return (
    <div className={classes.createPost}>
      <AuthorInfo author={user} />
      <div className={classes.createPostActions}>
        <TextField
          label="Поделитесь вашими мыслями ..."
          multiline
          rows={5}
          value={text}
          onChange={e => setText(e.target.value)}
          className={classes.editField}
          disabled={pending}
        />
        <input
          accept="image/*"
          className={classes.input}
          id="icon-button-file"
          type="file"
          ref={imageInput}
          disabled={pending}
          onChange={() =>
            setColor(color === "secondary" ? "primary" : "secondary")
          }
        />
        <label htmlFor="icon-button-file">
          <IconButton aria-label="upload picture" component="span" size="small">
            <CameraAltIcon color={color} className={classes.icon} />
          </IconButton>
        </label>
        {imageInput.current?.files.length ? (
          <IconButton
            aria-label="upload picture"
            component="span"
            size="small"
            onClick={() => {
              imageInput.current.value = null;
              setColor("secondary");
            }}
          >
            <ClearIcon color="inherit" className={classes.icon} />
          </IconButton>
        ) : (
          ""
        )}
      </div>
      <Button
        variant="contained"
        color="primary"
        disabled={
          pending || (!text.length && !imageInput.current?.value.length)
        }
        className={classes.createButton}
        onClick={async () => await createPost()}
      >
        {pending ? (
          <CircularProgress size={"1.5rem"} className={classes.pending} />
        ) : (
          <span>СОЗДАТЬ</span>
        )}
      </Button>
    </div>
  );
};

export const Post = ({
  id,
  text,
  image,
  author,
  date,
  comments,
  likes,
  premissions,
  setPosts,
  viewer
}) => {
  const classes = useStyles();
  likes = likes.map(l => l.id);
  const [liked, setLiked] = useState(likes.includes(viewer.id));
  let likeCount = likes.length;
  const toggleLike = async () => {
    await fetch(`https://tj791.sse.codesandbox.io/posts/like/${id}`, {
      method: "post",
      body: JSON.stringify({
        viewerId: viewer.id
      }),
      headers: {
        "content-type": "application/json"
      }
    });
    setLiked(!liked);
    setPosts(await fetchPosts(viewer.id));
  };
  const handleRemove = async id => {
    await fetch(`https://tj791.sse.codesandbox.io/posts/${id}`, {
      method: "DELETE"
    });
    setPosts(await fetchPosts(author.id));
  };
  return (
    <div className={classes.post}>
      <AuthorInfo
        className={classes.postHead}
        author={author}
        date={new Date(date).toLocaleDateString()}
        premissions={premissions}
        remove={async () => await handleRemove(id)}
      />
      <div className={classes.postBody}>
        {text ? (
          <Typography variant="body1" className={classes.text}>
            {text}
          </Typography>
        ) : (
          ""
        )}

        {image ? (
          <img
            className={classes.postImage}
            src={`https://tj791.sse.codesandbox.io/uploads/${image}`}
            alt={image}
          />
        ) : (
          ""
        )}
      </div>
      <div className={classes.postActions}>
        <IconButton
          aria-label="Like"
          component="span"
          size="small"
          onClick={async () => await toggleLike()}
        >
          {liked ? (
            <FavoriteIcon color="secondary" className={classes.icon} />
          ) : (
            <FavoriteBorderIcon color="secondary" className={classes.icon} />
          )}
          {likeCount}
        </IconButton>
      </div>
    </div>
  );
};

export default function Feed({ user }) {
  const classes = useStyles();
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    (async () => {
      setPosts(await fetchPosts(user.id));
    })();
  }, [user]);

  return (
    <Paper
      className={classes.feed}
      variant="outlined"
      elevation={3}
      children={
        <div className="container">
          <Typography variant="h5" className={classes.text} color="primary">
            Новостная лента
          </Typography>
          <Box className={classes.postContainer}>
            <CreatePost user={user} setPosts={setPosts} />
            <div className="post">
              {posts.length ? (
                posts.map(p => (
                  <Post
                    viewer={user}
                    key={p.id}
                    {...p}
                    premissions={p.author.id === user.id}
                    setPosts={setPosts}
                  />
                ))
              ) : (
                <Typography
                  variant="body1"
                  className={classes.warning}
                  color="secondary"
                >
                  Постов нет
                </Typography>
              )}
            </div>
          </Box>
        </div>
      }
    />
  );
}
