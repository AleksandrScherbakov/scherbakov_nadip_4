import React, { useState } from "react";
import bcrypt from "bcryptjs";
import { v4 } from "uuid";
import {
  Paper,
  FormControl,
  Input,
  InputLabel,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions
} from "@material-ui/core";
import { A } from "hookrouter";

const SignupForm = ({ isopen, handleClose, handleSubmit, handleChange }) => {
  return (
    <div className="signupForm">
      <Dialog
        onClose={handleClose}
        aria-labelledby="simple-dialog-title"
        open={isopen}
        className="signupDialog"
      >
        <DialogTitle>Новый аккаунт</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Новый аккаунт успешно зарегистрирован
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <A href="/signin">
            <Button variant="contained" color="primary" onClick={handleClose}>
              ВОЙТИ
            </Button>
          </A>
        </DialogActions>
      </Dialog>
      <Typography variant="h6" align="center" color="primary">
        Регистрация
      </Typography>
      <form onSubmit={e => handleSubmit(e)}>
        <FormControl margin="normal" required>
          <InputLabel htmlFor="login-input">Логин</InputLabel>
          <Input
            id="login-input"
            aria-describedby="Введите логин"
            fullWidth
            type="text"
            autoFocus
            onChange={e => handleChange(e, "login")}
          />
        </FormControl>
        <br />
        <FormControl margin="normal" required>
          <InputLabel htmlFor="email-input">Email</InputLabel>
          <Input
            id="email-input"
            aria-describedby="Введите Email"
            fullWidth
            type="email"
            onChange={e => handleChange(e, "email")}
          />
        </FormControl>
        <br />
        <FormControl margin="normal" required>
          <InputLabel htmlFor="password-input">Пароль</InputLabel>
          <Input
            id="password-input"
            aria-describedby="Введите пароль"
            fullWidth
            type="password"
            onChange={e => handleChange(e, "password")}
          />
        </FormControl>
        <br />
        <FormControl margin="normal">
          <Button variant="contained" color="primary" type="submit">
            ЗАРЕГИСТРИРОВАТЬСЯ
          </Button>
        </FormControl>
      </form>
    </div>
  );
};

export default function Signup() {
  const [open, setOpen] = useState(false);
  const [login, setLogin] = useState(null);
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

  const handleChange = (e, title) => {
    const { value } = e.currentTarget;
    if (title === "login") {
      setLogin(value);
    } else if (title === "email") {
      setEmail(value);
    } else if (title === "password") {
      setPassword(value);
    }
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = async e => {
    e.preventDefault();
    let hashPassword = await bcrypt.hash(password, 10);
    await fetch("https://tj791.sse.codesandbox.io/auth/signup", {
      method: "post",
      body: JSON.stringify({
        id: v4(),
        login,
        email,
        password: hashPassword,
        registerDate: new Date().toLocaleDateString()
      }),
      headers: {
        "content-type": "application/json"
      }
    }).then(res => {
      if (res.ok) {
        setOpen(true);
      }
    });
  };
  return (
    <Paper
      className="container"
      variant="outlined"
      elevation={3}
      children={
        <SignupForm
          isopen={open}
          handleClose={handleClose}
          handleSubmit={handleSubmit}
          handleChange={handleChange}
        />
      }
    />
  );
}
