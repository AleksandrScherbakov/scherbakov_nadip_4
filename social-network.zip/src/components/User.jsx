import React, { useState, useEffect } from "react";
import {
  Typography,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Avatar,
  Tabs,
  Tab,
  Box
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Edit";
import useAuth from "../hooks/useAuth";
import useSubscribe from "../hooks/useSubscribe";
import { navigate, A } from "hookrouter";
import getToken from "../middlewares/getToken";
import subscribe from "../middlewares/subscribe";
import unsubscribe from "../middlewares/unsubscribe";
import { Post } from "./Feed";
const useStyles = makeStyles(theme => ({
  image: {
    width: "100%",
    height: "100%"
  },
  text: {
    padding: theme.spacing(1.5) + " " + theme.spacing(2)
  },
  line: {
    margin: "0 " + theme.spacing(1)
  },
  large: {
    width: theme.spacing(4),
    height: theme.spacing(4)
  },
  icon: {
    margin: theme.spacing(1),
    cursor: "pointer"
  },
  post: {
    background: theme.palette.back.light,
    marginBottom: theme.spacing(2)
  },
  authorInfo: {
    display: "flex",
    justifyContent: "flex-start",
    padding: theme.spacing(0.5) + " " + theme.spacing(1),
    alignItems: "center",
    width: "auto"
  },
  input: {
    display: "none"
  },
  createButton: {
    margin: theme.spacing(1)
  },
  userLogin: {
    marginLeft: theme.spacing(1),
    width: "calc(100% - " + theme.spacing(3) + ")",
    display: "flex",
    justifyContent: "space-between"
  },
  postImage: {
    display: "inline-block",
    maxWidth: "300px",
    maxHeight: "400px",
    margin: theme.spacing(1) + " 30%"
  },
  userCard: {
    width: theme.spacing(4),
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  },
  userCardUsername: {
    marginTop: theme.spacing(1)
  },
  warning: {
    padding: theme.spacing(1.5) + " " + theme.spacing(2),
    width: "auto",
    textAlign: "center"
  }
}));

const fetchUser = async id => {
  let user = await fetch(
    `https://tj791.sse.codesandbox.io/userinfo/${id}`
  ).then(res => res.json());
  return user;
};

const fetchSubscriptions = async id => {
  let subscriptions = await fetch(
    `https://tj791.sse.codesandbox.io/userinfo/subscriptions/${id}`
  ).then(res => res.json());
  return subscriptions;
};
const fetchSubscribers = async id => {
  let subscribers = await fetch(
    `https://tj791.sse.codesandbox.io/userinfo/subscribers/${id}`
  ).then(res => res.json());
  return subscribers;
};
const fetchPosts = async userId => {
  let posts = await fetch(
    `https://tj791.sse.codesandbox.io/posts/posts/${userId}`
  ).then(res => res.json());
  posts = posts.filter(p => Object.keys(p).length !== 0);
  return posts;
};

const deleteUser = async id => {
  let res = await fetch(`https://tj791.sse.codesandbox.io/userinfo/${id}`, {
    method: "DELETE"
  });
  if (res.status === 200) {
    localStorage.removeItem("token");
    navigate("/");
  } else {
    res = await res.json();
    console.error(res.err);
  }
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={2}>{children}</Box>}
    </div>
  );
}

const UserCard = ({ user }) => {
  const classes = useStyles();
  return (
    <div className={classes.userCard}>
      <A href={`/user/${user.id}`}>
        <Avatar src={user.avatar} className={classes.large} />
      </A>
      <Typography variant="body1" className={classes.userCardUsername}>
        {user.login}
      </Typography>
    </div>
  );
};

const UserInfo = ({ candidate }) => {
  const classes = useStyles();
  return (
    <div className="user-info">
      <Avatar
        src={candidate ? candidate.avatar : ""}
        className={classes.large}
      />
      <div className="user-login">
        <Typography variant="body1">
          {candidate ? candidate.login : "Логин"}
        </Typography>
        <Typography variant="subtitle2" color="textSecondary">
          {candidate ? candidate.email : "users@email.com"}
        </Typography>
      </div>
    </div>
  );
};

export const ActionButton = ({ user, candidate }) => {
  let isSubscribed = useSubscribe(user, candidate);
  const [sub, setSub] = useState(isSubscribed);
  return sub ? (
    <Button
      variant="contained"
      color="primary"
      onClick={async () => setSub(await unsubscribe(user, candidate))}
    >
      ОТПИСАТЬСЯ
    </Button>
  ) : (
    <Button
      variant="contained"
      color="primary"
      onClick={async () => setSub(await subscribe(user, candidate))}
    >
      ПОДПИСАТЬСЯ
    </Button>
  );
};

const UserActions = ({ isOpen, handleToggle, deleteUser, user, candidate }) => {
  const classes = useStyles();
  let editPermissions = user && candidate ? user.id === candidate.id : false;
  return (
    <div className="uesr-actions">
      {editPermissions ? (
        <>
          <Dialog
            onClose={handleToggle}
            aria-labelledby="simple-dialog-title"
            open={isOpen}
            className="signupDialog"
          >
            <DialogTitle>Удаление аккаунта</DialogTitle>
            <DialogContent>
              <DialogContentText>
                Подтвердите удаление аккаунта
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button color="primary" onClick={handleToggle}>
                ОТМЕНА
              </Button>
              <Button color="secondary" onClick={deleteUser}>
                ПОДТВЕРДИТЬ
              </Button>
            </DialogActions>
          </Dialog>
          <EditIcon color="primary" className={classes.icon} />
          <DeleteIcon
            color="secondary"
            className={classes.icon}
            onClick={handleToggle}
          />
        </>
      ) : (
        <ActionButton user={user} candidate={candidate} />
      )}
    </div>
  );
};

export default function User({ id }) {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  let token = getToken();
  let { user } = useAuth(token);

  const [candidate, setCandidate] = useState(undefined);
  const [posts, setPosts] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [subscribers, setSubscribers] = useState([]);
  useEffect(() => {
    (async () => {
      setCandidate(await fetchUser(id));
      setPosts(await fetchPosts(id));
      setSubscriptions(await fetchSubscriptions(id));
      setSubscribers(await fetchSubscribers(id));
    })();
  }, [id]);
  /*
  const [isSubscribed, setIsSubscribed] = useState(
    user && candidate
      ? user.subscriptions.map(s => s.id).includes(candidate._id)
      : false
  );
*/
  const handleToggle = () => {
    setOpen(!open);
  };
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Paper
      className="container"
      variant="outlined"
      elevation={3}
      children={
        <div className="container">
          <Typography variant="h5" className={classes.text} color="secondary">
            Профиль
          </Typography>
          <div className="user">
            <UserInfo candidate={candidate} />
            <UserActions
              isOpen={open}
              handleToggle={handleToggle}
              deleteUser={() => deleteUser(user ? user.id : "")}
              user={user}
              candidate={candidate}
            />
          </div>
          <hr className={classes.line} />
          <Typography
            variant="subtitle2"
            className={classes.text}
            color="textSecondary"
          >
            Зарегистрировался:{" "}
            {candidate
              ? candidate.registerDate
              : new Date().toLocaleDateString()}
          </Typography>
          <Tabs
            value={value}
            onChange={handleChange}
            indicatorColor="primary"
            textColor="primary"
            centered
          >
            <Tab label="ПОСТЫ" />
            <Tab label="ПОДПИСКИ" />
            <Tab label="ПОДПИСЧИКИ" />
          </Tabs>
          <TabPanel value={value} index={0}>
            {posts.length ? (
              posts.map(p => (
                <Post
                  viewer={user}
                  key={p.id}
                  {...p}
                  premissions={p.author.id === user.id}
                  setPosts={setPosts}
                />
              ))
            ) : (
              <Typography
                variant="body1"
                className={classes.warning}
                color="secondary"
              >
                Постов нет
              </Typography>
            )}
          </TabPanel>
          <TabPanel value={value} index={1}>
            <Box
              display="flex"
              flexDirection="row"
              flexWrap="wrap"
              justifyContent="space-around"
            >
              {subscriptions.length ? (
                subscriptions.map(s => <UserCard user={s} key={s.id} />)
              ) : (
                <Typography
                  variant="body1"
                  className={classes.warning}
                  color="secondary"
                >
                  Подписок нет
                </Typography>
              )}
            </Box>
          </TabPanel>
          <TabPanel value={value} index={2}>
            <Box
              display="flex"
              flexDirection="row"
              flexWrap="wrap"
              justifyContent="space-around"
            >
              {subscribers.length ? (
                subscribers.map(s => <UserCard user={s} key={s.id} />)
              ) : (
                <Typography
                  variant="body1"
                  className={classes.warning}
                  color="secondary"
                >
                  Подписчиков нет
                </Typography>
              )}
            </Box>
          </TabPanel>
        </div>
      }
    />
  );
}
