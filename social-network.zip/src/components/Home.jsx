import React from "react";
import { Typography, Paper } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import HomeImage from "../images/home.jpg";
import useAuth from "../hooks/useAuth";
import getToken from "../middlewares/getToken";
import Possible from "./Possible";
import Feed from "./Feed";

const useStyles = makeStyles({
  image: {
    width: "auto",
    height: "100%"
  },
  text: {
    padding: "1.5rem 2rem"
  }
});

const HomePage = () => {
  const classes = useStyles();
  return (
    <Paper
      className="container"
      variant="outlined"
      elevation={3}
      children={
        <div className="container">
          <Typography variant="h5" className={classes.text}>
            Главная
          </Typography>
          <img
            src={HomeImage}
            alt="Домашняя страница"
            className={classes.image}
          />
          <Typography variant="body1" className={classes.text}>
            Добро пожаловать на глваную страницу Social Network.
          </Typography>
        </div>
      }
    />
  );
};

export default function Home() {
  let token = getToken();
  let { user } = useAuth(token);
  if (user) {
    return (
      <div className="container home-container">
        <Feed user={user} />
        <Possible user={user} />
      </div>
    );
  } else {
    return <HomePage />;
  }
}
