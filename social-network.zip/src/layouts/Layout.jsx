import React from "react";
import { Menu } from "../components/Menu";
import { ThemeProvider } from "@material-ui/core";
import { createMuiTheme } from "@material-ui/core/styles";
import { teal, grey } from "@material-ui/core/colors";

const theme = createMuiTheme({
  palette: {
    primary: {
      main: teal[600],
      light: teal[50],
      contrastText: "#fff"
    },
    secondary: {
      main: "#ff9100",
      contrastText: "#000"
    },
    back: {
      main: grey[400],
      light: grey[200],
      white: grey[50]
    }
  },
  spacing: factor => `${factor}rem`
});

export function Layout({ children }) {
  return (
    <ThemeProvider theme={theme}>
      <Menu />
      <div className="layout">{children}</div>
    </ThemeProvider>
  );
}
