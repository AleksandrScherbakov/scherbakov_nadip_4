import { useState, useEffect } from "react";

function useAuth(token) {
  const [isAuth, setIsAuth] = useState(false);
  const [user, setUser] = useState(null);
  const fetchToken = async token => {
    if (token.length === 0) return { status: false, user: undefined };
    else {
      let res = await fetch(
        `https://tj791.sse.codesandbox.io/auth/checkToken/${token}`
      );
      let status = res.ok;
      if (status) {
        let user = JSON.parse(await res.json());
        return { status, user };
      } else {
        return { status, user: undefined };
      }
    }
  };
  useEffect(() => {
    (async () => {
      let { status, user } = await fetchToken(token);
      setIsAuth(status);
      setUser(user);
    })();
  }, [token]);
  return { auth: isAuth, user: user };
}

export default useAuth;
