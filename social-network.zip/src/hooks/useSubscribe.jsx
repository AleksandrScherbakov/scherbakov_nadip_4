import { useState, useEffect } from "react";

function useSubscribe(user, candidate) {
  const [isSubscribed, setIsSubscribed] = useState(
    user && candidate
      ? user.subscriptions.map(s => s.id).includes(candidate.id)
      : null
  );
  useEffect(() => {
    if (user && candidate) {
      setIsSubscribed(user.subscriptions.map(s => s.id).includes(candidate.id));
    }
  }, [user, candidate]);
  if (user && candidate) {
    return isSubscribed;
  }
}

export default useSubscribe;
