import React from "react";
import "./styles.css";
import { Layout } from "./layouts/Layout";
import Home from "./components/Home";
import Signup from "./components/Signup";
import Signin from "./components/Signin";
import User from "./components/User";
import { useRoutes } from "hookrouter";
/*
  "/user/edit/:id": ({ id }) => <UserEdit id={id} />
*/
const routes = {
  "/": () => <Home />,
  "/signin": () => <Signin />,
  "/signup": () => <Signup />,
  "/user/:id": ({ id }) => <User id={id} />
};
export default function App() {
  const routeResult = useRoutes(routes);
  return <Layout>{routeResult}</Layout>;
}
