const unsubscribe = async (user, candidate) => {
  const id = user.id;
  const candidateId = candidate.id;
  let res = await fetch(
    `https://tj791.sse.codesandbox.io/userinfo/unsubscribe/${candidateId}`,
    {
      method: "post",
      body: JSON.stringify({ id }),
      headers: {
        "content-type": "application/json"
      }
    }
  );
  return !res.status === 200;
};

export default unsubscribe;
