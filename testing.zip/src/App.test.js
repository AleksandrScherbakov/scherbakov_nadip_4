import React from "react";
import { configure, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import App from "./App";

configure({ adapter: new Adapter() });

describe("Application component", () => {
  let component, password;

  beforeEach(() => {
    component = shallow(<App />);
  });

  beforeEach(() => {
    component.instance().generatePassword();
    password = component.state("password");
  });

  it("Render App", () => {
    expect(component).toBeTruthy();
  });

  it("Get password", () => {
    expect(password).toBeTruthy();
  });

  it("Uppercase symbol check", () => {
    if (password.search(/[A-Z]/) !== -1) {
      expect(component.state("uppercase") === true);
    } else {
      expect(component.state("uppercase")).toBeFalsy();
    }
  });

  it("Lowercase symbol check", () => {
    if (password.search(/[a-z]/) !== -1) {
      expect(component.state("lowercase") === true);
    } else {
      expect(component.state("lowercase")).toBeFalsy();
    }
  });

  it("Special symbol check", () => {
    if (password.search(/[^`@#$%^&*\-_=+'/.,]/) !== -1) {
      expect(component.state("special") === true);
    } else {
      expect(component.state("special")).toBeFalsy();
    }
  });

  it("Number check", () => {
    if (password.search(/\d/) !== -1) {
      expect(component.state("number") === true);
    } else {
      expect(component.state("number")).toBeFalsy();
    }
  });

  it("More than 6 symbols check", () => {
    if (password.length > 6) {
      expect(component.state("length") === true);
    } else {
      expect(component.state("length")).toBeFalsy();
    }
  });
});
