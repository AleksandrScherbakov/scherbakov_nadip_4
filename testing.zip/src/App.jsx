import React from "react";
import _ from "lodash";
import "./styles.css";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      showPassword: false,
      password: "",
      uppercase: false,
      lowercase: false,
      special: false,
      number: false,
      length: false
    };
    this.generatePassword = this.generatePassword.bind(this);
    this.checkPassword = this.checkPassword.bind(this);
    this._debouncedOnChange = _.debounce(this.checkPassword, 100);
  }
  generatePassword() {
    //33-126
    let newPassword = "";
    for (let i = 1; i <= 12; i++) {
      let num = Math.floor(Math.random() * 94) + 33;
      newPassword += String.fromCharCode(num);
    }
    this.setState({
      password: newPassword
    });
  }
  checkPassword() {
    let { password } = this.state;
    if (password.search(/[A-Z]/) !== -1) {
      this.setState({ uppercase: true });
    } else {
      this.setState({ uppercase: false });
    }
    if (password.search(/[a-z]/) !== -1) {
      this.setState({ lowercase: true });
    } else {
      this.setState({ lowercase: false });
    }
    if (password.search(/\d/) !== -1) {
      this.setState({ number: true });
    } else {
      this.setState({ number: false });
    }
    if (password.search(/[\^`@#$%^&*\-_=+'/.,]/) !== -1) {
      this.setState({ special: true });
    } else {
      this.setState({ special: false });
    }
    if (password.length >= 6) {
      this.setState({ length: true });
    } else {
      this.setState({ length: false });
    }
  }
  render() {
    let { uppercase, lowercase, number, special, length } = this.state;
    return (
      <div className="App">
        <h1>Виджет пароля</h1>
        <div className="container">
          <form
            onSubmit={e => {
              e.preventDefault();
              this._debouncedOnChange();
            }}
          >
            <div className="group">
              <label htmlFor="password">Пароль</label>
              <br />
              <input
                type={this.state.showPassword ? "text" : "password"}
                id="password"
                name="password"
                onChange={e => {
                  this.setState({ password: e.target.value });
                  this._debouncedOnChange();
                }}
                value={this.state.password}
              />
            </div>
            <br />
            <div className="group">
              <input
                type="checkbox"
                name="check"
                id="check"
                onChange={() => {
                  this.setState({ showPassword: !this.state.showPassword });
                }}
              />
              <label htmlFor="check">Показать пароль</label>
            </div>
          </form>
          <p>Сложность пароля</p>
          <ul>
            {uppercase ? (
              <li>
                <del>Должен иметь хотя бы один символ в верхнем регистре</del>
              </li>
            ) : (
              <li>Должен иметь хотя бы один символ в верхнем регистре</li>
            )}

            {lowercase ? (
              <li>
                <del>Должен иметь хотя бы один символ в нижнем регистре</del>
              </li>
            ) : (
              <li>Должен иметь хотя бы один символ в нижнем регистре</li>
            )}

            {special ? (
              <li>
                <del>
                  Должен иметь хотя бы один специальный символ
                  (&#35;&#36;&#64;&#33;&#38;&#37;...)
                </del>
              </li>
            ) : (
              <li>
                Должен иметь хотя бы один специальный символ
                (&#35;&#36;&#64;&#33;&#38;&#37;...)
              </li>
            )}

            {number ? (
              <li>
                <del>Должен иметь хотя бы одну цифру</del>
              </li>
            ) : (
              <li>Должен иметь хотя бы одну цифру</li>
            )}
            {length ? (
              <li>
                <del>Должен иметь не менее 6 символов</del>
              </li>
            ) : (
              <li>Должен иметь не менее 6 символов</li>
            )}
          </ul>
          <button
            onClick={() => {
              this.generatePassword();
              this.checkPassword();
            }}
          >
            Сгенерировать
          </button>
          <button onClick={this._debouncedOnChange}>Проверить</button>
        </div>
      </div>
    );
  }
}
