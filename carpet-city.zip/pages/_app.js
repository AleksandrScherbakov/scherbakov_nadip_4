import App from "next/app";
import React from "react";
import Menu from "../components/menu";

class MyApp extends App {
  render() {
    const { Component, pageProps } = this.props;
    return (
      <div id="main">
        <Menu />
        <Component {...pageProps} />{" "}
        <footer>
          <span>
            Сайт был сделан на <a href="https://nextjs.org/">NextJS</a> и{" "}
            <a href="https://snipcart.com/">Snipcart</a>
          </span>
          <span>
            <a href="https://twitter.com/">Twitter</a> |{" "}
            <a href="https://facebook.com/">Facebook</a> |{" "}
            <a href="https://github.com">Github</a>
          </span>
        </footer>
      </div>
    );
  }
}

export default MyApp;
