import React from "react";
import { connect } from "react-redux";
import Products from "../components/products";
import Head from "next/head";
import fetch from "isomorphic-unfetch/index";

class Index extends React.Component {
  static async getInitialProps() {
    const res = await fetch("http://localhost:3000/api/products");
    const json = await res.json();
    return { products: json };
  }
  render() {
    return (
      <div>
        <Head>
          <title>Carpet City | Онлайн магазин ковров</title>
          <link rel="stylesheet" href="../static/style.css" />
          <link
            rel="stylesheet"
            href="https://cdn.snipcart.com/themes/v3.0.11/default/snipcart.css"
          />
          <link
            rel="shortcut icon"
            href="../static/img/favicon.png"
            type="image/png"
          />
          <meta name="title" content="Магазин ковров | Carpet City" />
          <meta
            name="description"
            content="Онлайн-магазин ковров Carpet City"
          />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
        </Head>
        <Products products={this.props.products} />{" "}
        <div
          id="snipcart"
          data-api-key="YTgwNzFjNWYtMWU0ZS00ZjM1LWE4ZjYtMWYzNTg2MGY0Yzk5NjM3MjE2Njg2NTIzMDU3NTE3"
          hidden
        />
        <script src="https://cdn.snipcart.com/themes/v3.0.11/default/snipcart.js" />
      </div>
    );
  }
}

export default Index;
