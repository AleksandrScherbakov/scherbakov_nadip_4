import { createStore } from "redux";
export const actionTypes = {};
let initialState = {
  products: [
    {
      id: "1",
      price: "25",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      image: "../static/img/straight-and-narrow.jpg",
      name: "Straight and Narrow"
    },
    {
      id: "2",
      price: "25",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      image: "../static/img/casonova.jpg",
      name: "Casonova"
    },
    {
      id: "3",
      price: "25",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      image: "../static/img/living-bliss.jpg",
      name: "Living Bliss"
    },
    {
      id: "4",
      price: "25",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      image: "../static/img/timeless-beige.jpg",
      name: "Timaless Beige"
    }
  ]
};
export const reducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export function initializeStore(initialState = initialState) {
  return createStore(reducer, initialState);
}

export { initialState };
