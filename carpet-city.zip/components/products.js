import React from "react";
import dynamic from "next/dynamic";

const Product = dynamic(() => import("./product"), {
  loading: () => <div>Загрузка...</div>
});

const Products = ({ products }) => (
  <div className="products">
    {products.map(props => (
      <Product key={props.id} {...props} />
    ))}
  </div>
);

export default Products;
