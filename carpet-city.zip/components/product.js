import React from "react";

const info = props => (
  <div className="info">
    <h1>{props.name}</h1>
    <p>{props.description}</p>
    <button
      className="snipcart-add-item"
      data-item-name={props.name}
      data-item-id={props.id}
      data-item-image={props.image}
      data-item-url="/"
      data-item-price={props.price}
      data-item-custom1-name="Size"
      data-item-custom1-options="4x6|10x10[+30.00]|20x20[+40.00]"
    >
      ДОБВАИТЬ В КОРЗИНУ ${props.price}
    </button>
  </div>
);

const image = props => (
  <img src={props.image} alt={props.name} className="thumbnail" />
);

function Product(props) {
  return (
    <div className="product">
      {info(props)}
      {image(props)}
    </div>
  );
}

export default Product;
