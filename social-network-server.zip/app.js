const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const mongoose = require("mongoose");
const cors = require("cors");
const multer = require("multer");

const indexRouter = require("./routes/index");
const authRouter = require("./routes/auth");
const userInfoRouter = require("./routes/userInfo");
const postRouter = require("./routes/posts");

const app = express();

const connectionString =
  "mongodb+srv://Alexandr:AoEXm2SnJSTkIRLc@clusterdev-6wuat.mongodb.net/SocialNetwork";

const storageConfig = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/jpeg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

app.use(cors());

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(__dirname));
app.use(
  multer({ storage: storageConfig, fileFilter: fileFilter }).single("image")
);

app.use("/", indexRouter);
app.use("/auth", authRouter);
app.use("/userinfo", userInfoRouter);
app.use("/posts", postRouter);

mongoose.connect(connectionString, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

async function start() {
  try {
    await mongoose.connect(
      "mongodb+srv://Alexandr:AoEXm2SnJSTkIRLc@clusterdev-6wuat.mongodb.net/SocialNetwork",
      { useNewUrlParser: true, useUnifiedTopology: true }
    );
    app.listen(8080, () => {
      console.log("Running app");
    });
  } catch (e) {
    console.log(e);
  }
}

start();
