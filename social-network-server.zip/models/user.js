const { Schema, model } = require("mongoose");
const Post = require("./post");
const userSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  login: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  registerDate: {
    type: String,
    required: true
  },
  avatar: {
    type: String
  },
  about: {
    type: String
  },
  subscriptions: [
    {
      id: String,
      objId: String
    }
  ],
  subscribers: [
    {
      id: String,
      objId: String
    }
  ],
  posts: [
    {
      type: Schema.Types.ObjectId,
      ref: "Post"
    }
  ]
});

userSchema.methods.addSubscription = async function(candidate) {
  try {
    if (candidate) {
      candidate.subscribers.push({ id: this.id, objId: this._id });
      this.subscriptions.push({ id: candidate.id, objId: candidate._id });
      await this.save();
      await candidate.save();
      return true;
    } else {
      return false;
    }
  } catch (e) {
    console.error(e);
  }
};

userSchema.methods.removeSubscription = async function(candidate) {
  try {
    if (candidate) {
      candidate.subscribers.shift({ id: this.id });
      this.subscriptions.shift({ id: candidate.id });
      await this.save();
      await candidate.save();
      return true;
    } else {
      return false;
    }
  } catch (e) {
    console.error(e);
  }
};

userSchema.methods.usersPosts = async function() {
  try {
    let posts = await Post.find({ anchor: this._id });
    if (posts) {
      posts.sort((a, b) => new Date(b.date) - new Date(a.date));
      return posts;
    } else {
      return [];
    }
  } catch (e) {
    console.log(e);
  }
};

userSchema.methods.getFeed = async function() {
  try {
    let userPosts = await this.usersPosts();
    let friends = this.subscriptions;
    if (friends.length) {
      let gotPosts = friends.map(async f => {
        const fPosts = await Post.find({ anchor: f.objId });
        return fPosts;
      });
      return await Promise.all(gotPosts).then(data => {
        let posts = userPosts.concat(data[0]);
        posts.sort((a, b) => new Date(b.date) - new Date(a.date));
        return posts;
      });
    } else {
      return userPosts;
    }
  } catch (e) {
    console.log(e);
  }
};

module.exports = model("User", userSchema, "users");
