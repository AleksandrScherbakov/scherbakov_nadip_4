const { Schema, model } = require("mongoose");

const postSchema = new Schema({
  id: {
    type: String,
    required: true
  },
  text: {
    type: String
  },
  image: {
    type: String
  },
  date: {
    type: Date,
    required: true
  },
  anchor: {
    type: Schema.Types.ObjectId,
    ref: "User"
  },
  author: {
    id: String,
    login: String,
    avatar: String
  },
  comments: [
    {
      id: {
        type: String
      },
      user: {
        login: String,
        avatar: String
      },
      date: Date,
      text: String
    }
  ],
  likes: [
    {
      id: String
    }
  ]
});

module.exports = model("Post", postSchema, "posts");
