const express = require("express");
const User = require("../models/user");
const Post = require("../models/post");
const fs = require("fs");
const router = express.Router();
const cors = require("cors");
let corsOptions = {
  origin: "*",
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  optionsSuccessStatus: 204
};

router.get("/feed/:id", async (req, res) => {
  try {
    const { id } = req.params;
    let user = await User.findOne({ id });
    let posts = await user.getFeed();
    if (posts) {
      res.status(200);
      res.json(posts);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.get("/posts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    let user = await User.findOne({ id });
    let posts = await user.usersPosts();
    if (posts) {
      res.status(200);
      res.json(posts);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    let candidate = await Post.findOne({ id });
    if (candidate.image) {
      fs.unlink(`uploads/${candidate.image}`, function(err) {
        if (err) throw err;
      });
    }
    if (candidate) {
      await Post.deleteOne({ id }, err => {
        if (err) res.json({ err });
        else res.sendStatus(200);
      });
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.post("/", cors(corsOptions), async (req, res) => {
  try {
    const { id, text, author, date, image } = JSON.parse(req.body.info);
    let candidate = await User.findOne({ id: author.id });
    if (candidate) {
      await candidate.save(err => {
        if (err) console.error(err);
        const post = new Post({
          id,
          text,
          anchor: candidate._id,
          author,
          date: new Date(date),
          image
        });
        post.save();
      });
      res.sendStatus(200);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.post("/like/:id", cors(corsOptions), async (req, res) => {
  try {
    let p = await Post.findOne({ id: req.params.id });
    const { viewerId } = req.body;
    console.log(typeof viewerId);
    let candidate = await User.findOne({ id: viewerId });
    if (candidate && p) {
      let likes = p.likes.map(l => l.id);
      console.log(likes);
      if (likes.includes(viewerId)) {
        p.likes = p.likes.filter(l => l.id !== viewerId);
        await p.save();
        res.sendStatus(200);
      } else {
        p.likes = p.likes.concat([{ id: viewerId }]);
        await p.save();
        res.sendStatus(200);
      }
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

module.exports = router;
