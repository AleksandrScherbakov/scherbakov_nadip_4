const express = require("express");
const User = require("../models/user");
const router = express.Router();
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const secret = "socialnetworksecret";

let corsOptions = {
  origin: "*",
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  optionsSuccessStatus: 204
};

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const candidate = await User.findOne({ id });
    if (candidate) {
      res.status(200);
      res.json(candidate);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    let candidate = await User.findOne({ id });
    if (candidate) {
      await User.deleteOne({ id }, err => {
        if (err) res.json({ err });
        else res.sendStatus(200);
      });
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.post("/subscribe/:candidateId", cors(corsOptions), async (req, res) => {
  try {
    const { candidateId } = req.params;
    const { id } = req.body;
    const user = await User.findOne({ id });
    const candidate = await User.findOne({ id: candidateId });
    let success = await user.addSubscription(candidate);
    if (success) {
      res.sendStatus(200);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.post(
  "/unsubscribe/:candidateId",
  cors(corsOptions),
  async (req, res) => {
    try {
      const { candidateId } = req.params;
      const { id } = req.body;
      const user = await User.findOne({ id });
      const candidate = await User.findOne({ id: candidateId });
      let success = await user.removeSubscription(candidate);
      if (success) {
        res.sendStatus(200);
      } else {
        res.sendStatus(500);
      }
    } catch (e) {
      console.error(e);
    }
  }
);

router.get("/some/:n", async (req, res) => {
  try {
    const { n } = req.params;
    let users = await User.aggregate([{ $sample: { size: +n } }]);
    users = users.map(user => {
      return { id: user.id, login: user.login, avatar: user.avatar };
    });
    if (users) {
      res.status(200);
      res.json(users);
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.get("/subscriptions/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const candidate = await User.findOne({ id });
    if (candidate) {
      let friends = candidate.subscriptions.map(async f => {
        const { id, avatar, login } = await User.findOne({ id: f.id });
        return { id, avatar, login };
      });
      await Promise.all(friends).then(data => {
        friends = data;
        res.status(200);
        res.json(friends);
      });
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.get("/subscribers/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const candidate = await User.findOne({ id });
    if (candidate) {
      let subscribers = candidate.subscribers.map(async f => {
        const { id, avatar, login } = await User.findOne({ id: f.id });
        return { id, avatar, login };
      });
      await Promise.all(subscribers).then(data => {
        subscribers = data;
        res.status(200);
        res.json(subscribers);
      });
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

router.put("/edit/:id", cors(corsOptions), async (req, res) => {
  try {
    const { id } = req.params;
    let candidate = await User.findOne({ id });
    const { login, about, email, password, token } = req.body;
    await jwt.verify(token, secret, async (err, decoded) => {
      if (err || candidate.email !== decoded.email) {
        res.status(401).send("Unauthorized: Invalid token");
      } else {
        candidate = {
          ...candidate,
          login,
          about,
          email,
          password
        };
        await candidate.save();
        const payload = { email };
        const token = jwt.sign(payload, secret, {
          expiresIn: "6h"
        });
        req.user = candidate;
        res.json({ token }).sendStatus(200);
      }
    });
    if (candidate) {
      let subscribers = candidate.subscribers.map(async f => {
        const { id, avatar, login } = await User.findOne({ id: f.id });
        return { id, avatar, login };
      });
      await Promise.all(subscribers).then(data => {
        subscribers = data;
        res.status(200);
        res.json(subscribers);
      });
    } else {
      res.sendStatus(500);
    }
  } catch (e) {
    console.error(e);
  }
});

module.exports = router;
