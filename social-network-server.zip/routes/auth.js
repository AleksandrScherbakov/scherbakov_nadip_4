const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user");
const cors = require("cors");

let corsOptions = {
  origin: "*",
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  optionsSuccessStatus: 204
};

const secret = "socialnetworksecret";

router.post("/signup", cors(corsOptions), async (req, res) => {
  const { id, login, email, password, registerDate } = req.body;
  try {
    let user = new User({
      id,
      login,
      email,
      password,
      registerDate,
      avatarUrl: "",
      about: ""
    });
    await user.save();
    res.sendStatus(200);
  } catch (e) {
    console.log(e);
  }
});

router.post("/signin", async (req, res) => {
  try {
    const { email, password } = req.body;
    const candidate = await User.findOne({ email });
    if (candidate) {
      const areSame = await bcrypt.compare(password, candidate.password);
      if (areSame) {
        const payload = { email };
        const token = jwt.sign(payload, secret, {
          expiresIn: "6h"
        });
        req.user = candidate;
        res.json({ token }).sendStatus(200);
      } else {
        res.json({ message: "Неверный пароль" });
      }
    } else {
      res.json({ message: "Пользователя с таким email нет" });
    }
  } catch (e) {
    console.log(e);
  }
});

router.get("/checkToken/:token", async (req, res) => {
  const { token } = req.params;
  if (!token) {
    res.status(401).send("Unauthorized: No token provided");
  } else {
    await jwt.verify(token, secret, async (err, decoded) => {
      if (err) {
        res.status(401).send("Unauthorized: Invalid token");
      } else {
        let user = await User.findOne({ email: decoded.email });
        res.status(200);
        res.json(JSON.stringify(user));
      }
    });
  }
});

module.exports = router;
