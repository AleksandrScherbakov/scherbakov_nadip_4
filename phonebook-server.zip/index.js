const { ApolloServer } = require("apollo-server");
const users = require("./db");

const typeDefs = `
  type Query {
    user(id: String!): User!
    users: [User!]!
  }

	type User {
    id: String!
    name: String!
		tel: String!
    city: String!
    street: String!
  }

  type Mutation {
    createUser(id: String!, name: String!, tel: String!, city: String!, street: String!): User!
    updateUser(id: String!, name: String!, tel: String!): User!
  }
`;

const resolvers = {
  Query: {
    user: (parent, { id }, context, info) => {
      return users.find(user => user.id === id);
    },
    users: (parent, args, context, info) => {
      return users;
    }
  },
  Mutation: {
    createUser: (parent, { id, name, tel, city, street }, context, info) => {
      const newUser = { id, name, tel, city, street };
      users.push(newUser);
      return newUser;
    },
    updateUser: (parent, { id, name, tel }, context, info) => {
      let newUser = users.find(user => user.id === id);
      newUser.name = name;
      newUser.tel = tel;
      return newUser;
    }
  }
};

const server = new ApolloServer({
  typeDefs,
  resolvers
});

server.listen().then(({ url }) => {
  console.log(`🚀 Server ready at ${url}`);
});
