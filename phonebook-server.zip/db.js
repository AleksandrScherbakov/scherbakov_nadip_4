const users = [
  {
    id: "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    name: "Сергей Петров",
    tel: "+7-999-888-77-66",
    city: "Москва",
    street: "ул. Пушкина, д. 42"
  },
  {
    id: "8b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    name: "Иван Иванов",
    tel: "+7-123-456-78-90",
    city: "Санкт-Петербург",
    street: "ул. Петропавловская, д. 2"
  },
  {
    id: "7b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    name: "Александр Щербаков",
    tel: "+7-111-222-33-44",
    city: "Москва",
    street: "ул. Ленина, д. 22"
  }
];
module.exports = users;
