import React from "react";
import "./styles.css";
import Image from "./Image";
import im1 from "./images/1.jpg";
import im2 from "./images/2.jpg";
import im3 from "./images/3.jpg";
import im4 from "./images/4.jpg";
import im5 from "./images/5.jpg";
import im6 from "./images/6.jpg";
import im7 from "./images/7.jpg";
import im8 from "./images/8.jpg";
import im9 from "./images/9.jpg";

const sources = [im1, im2, im3, im4, im5, im6, im7, im8, im9];

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      open: false,
      source: null
    };
    this.handleClick = this.handleClick.bind(this);
  }
  handleClick(e) {
    this.setState({ source: e.currentTarget.getAttribute("src") });
    this.setState({ open: !this.state.open });
  }
  render() {
    return (
      <div className="App">
        {this.state.open ? (
          <Image
            src={this.state.source}
            onClick={this.handleClick}
            className="opened"
          />
        ) : (
          sources.map(source => {
            return (
              <Image
                key={source.toString()}
                src={source}
                onClick={this.handleClick}
              />
            );
          })
        )}
      </div>
    );
  }
}
